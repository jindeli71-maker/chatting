# Gojo Chat - cPanel Setup Guide

This guide explains how to deploy the Gojo Chat system on cPanel hosting with different setup options.

## 📋 Prerequisites

- cPanel hosting account
- Domain with SSL certificate (HTTPS required for WebRTC)
- Basic knowledge of cPanel file manager

## 🚀 Setup Options

### Option 1: Basic Chat (No Server Required)

**Best for:** Simple chat interface without real-time calling between users

#### Steps:
1. **Access cPanel File Manager**
   - Login to your cPanel
   - Open "File Manager"
   - Navigate to `public_html` folder

2. **Upload Files**
   ```
   public_html/
   ├── gojo-chat/
   │   ├── index.html
   │   ├── webrtc.js
   │   └── README.md
   ```

3. **Set Permissions**
   - Right-click on `gojo-chat` folder
   - Set permissions to `755`

4. **Access Your Chat**
   - Visit: `https://yourdomain.com/gojo-chat/`
   - Allow camera/microphone permissions when prompted

**Features Available:**
- ✅ Chat interface
- ✅ UI animations
- ✅ Call popup (demo mode)
- ❌ Real-time calling between users

---

### Option 2: Full Setup with Node.js (Advanced)

**Best for:** Complete functionality with real-time calling

#### Requirements:
- cPanel with Node.js support
- Terminal access (SSH or cPanel Terminal)
- Custom port configuration

#### Steps:

1. **Check Node.js Support**
   - In cPanel, look for "Node.js" or "Node.js Selector"
   - If not available, contact your hosting provider

2. **Upload All Files**
   ```
   public_html/
   ├── gojo-chat/
   │   ├── index.html
   │   ├── webrtc.js
   │   ├── webrtc-enhanced.js
   │   ├── package.json
   │   ├── signaling-server.js
   │   └── README.md
   ```

3. **Create Node.js Application**
   - Go to "Node.js" in cPanel
   - Click "Create Application"
   - Set:
     - **Application Root**: `gojo-chat`
     - **Application URL**: `gojo-chat`
     - **Application Startup File**: `signaling-server.js`
     - **Node.js Version**: Latest (18.x or 20.x)

4. **Install Dependencies**
   - Open Terminal in cPanel
   - Navigate to your app: `cd gojo-chat`
   - Run: `npm install`

5. **Configure Environment**
   - In Node.js app settings, add environment variables:
     ```
     PORT=3001
     NODE_ENV=production
     ```

6. **Start Application**
   - Click "Start" in Node.js app settings
   - Note the port number assigned

7. **Update WebRTC Configuration**
   - Edit `webrtc-enhanced.js`
   - Change the socket connection URL:
   ```javascript
   // Change this line:
   this.socket = io('http://localhost:3001');
   
   // To:
   this.socket = io('https://yourdomain.com:PORT');
   ```

8. **Access Your Chat**
   - Visit: `https://yourdomain.com/gojo-chat/`
   - The signaling server will run on the assigned port

**Features Available:**
- ✅ Full chat interface
- ✅ Real-time calling between users
- ✅ File sharing
- ✅ Multiple room support

---

### Option 3: Static Hosting (GitHub Pages, Netlify, Vercel)

**Best for:** Free hosting with HTTPS

#### GitHub Pages:
1. Create a new repository
2. Upload all files
3. Enable GitHub Pages in repository settings
4. Access via: `https://username.github.io/repository-name`

#### Netlify:
1. Drag and drop the `gojo-chat` folder to Netlify
2. Deploy automatically
3. Get HTTPS URL

#### Vercel:
1. Connect your GitHub repository
2. Deploy with one click
3. Get HTTPS URL

---

## 🔧 Configuration Options

### Basic Configuration (Option 1)

If you only need the chat interface without real-time calling:

1. **Edit `index.html`**
   - Remove or comment out the WebRTC initialization
   - Keep only the chat functionality

2. **Customize Styling**
   ```css
   /* In index.html, modify these variables */
   :root {
       --primary-color: #00bfff;
       --secondary-color: #9d00ff;
       --accent-color: #87cefa;
   }
   ```

### Advanced Configuration (Option 2)

For full functionality:

1. **Configure STUN/TURN Servers**
   ```javascript
   // In webrtc.js or webrtc-enhanced.js
   const configuration = {
       iceServers: [
           { urls: 'stun:stun.l.google.com:19302' },
           // Add your own TURN servers for better connectivity
           {
               urls: 'turn:your-turn-server.com:3478',
               username: 'your-username',
               credential: 'your-password'
           }
       ]
   };
   ```

2. **Set Up Custom Domain**
   - Point your domain to the Node.js application
   - Configure SSL certificate
   - Update socket connection URL

---

## 🚨 Troubleshooting

### Common Issues:

1. **"Camera/Microphone Access Denied"**
   - Ensure you're using HTTPS
   - Check browser permissions
   - Try different browser

2. **"Connection Failed"**
   - Check if Node.js app is running
   - Verify port configuration
   - Check firewall settings

3. **"Socket Connection Error"**
   - Verify the socket URL in webrtc-enhanced.js
   - Check if signaling server is accessible
   - Ensure CORS is properly configured

4. **"Module Not Found"**
   - Run `npm install` in the correct directory
   - Check if all files are uploaded
   - Verify file permissions

### Debug Steps:

1. **Check Browser Console**
   - Press F12
   - Look for error messages
   - Check Network tab for failed requests

2. **Test HTTPS**
   - Ensure your domain has valid SSL certificate
   - Test with: `https://yourdomain.com`

3. **Verify File Upload**
   - Check if all files are in the correct location
   - Verify file permissions (644 for files, 755 for folders)

---

## 📱 Mobile Considerations

### Responsive Design:
- The chat interface is mobile-responsive
- Touch controls work on mobile devices
- Camera/microphone access works on mobile browsers

### Mobile Testing:
- Test on different devices
- Check portrait/landscape orientations
- Verify touch interactions

---

## 🔒 Security Considerations

### For Production Use:

1. **Enable HTTPS**
   - Required for WebRTC functionality
   - Use Let's Encrypt or commercial SSL

2. **Configure CORS**
   - Restrict access to your domain only
   - Update signaling server CORS settings

3. **Add Authentication**
   - Implement user login system
   - Add room passwords
   - Restrict access to authorized users

4. **Use TURN Servers**
   - For better connectivity
   - Required for some network configurations

---

## 📞 Support

### Getting Help:

1. **Check Browser Console**
   - Look for JavaScript errors
   - Check Network requests

2. **Test on Different Browsers**
   - Chrome, Firefox, Safari, Edge
   - Check compatibility

3. **Contact Hosting Provider**
   - Ask about Node.js support
   - Inquire about port configuration

4. **Review Documentation**
   - Check WebRTC browser support
   - Review cPanel Node.js documentation

---

## 🎯 Quick Start Checklist

### For Basic Setup:
- [ ] Upload `index.html` and `webrtc.js`
- [ ] Ensure HTTPS is enabled
- [ ] Test camera/microphone permissions
- [ ] Verify responsive design

### For Full Setup:
- [ ] Check Node.js support in cPanel
- [ ] Upload all files
- [ ] Create Node.js application
- [ ] Install dependencies (`npm install`)
- [ ] Configure environment variables
- [ ] Start the application
- [ ] Update socket connection URL
- [ ] Test real-time functionality

---

**"Throughout heaven and earth, I alone am the honored one."** - Gojo Satoru

*Built with ❤️ by Eugene @ Synergy College*
