# Gojo Chat - Voice & Video Calls

A WhatsApp-style chat interface with integrated voice and video calling functionality, featuring a beautiful Gojo Satoru theme.

## 🌟 Features

- **WhatsApp-style Chat Interface** - Clean, modern chat UI
- **Voice Calls** - High-quality audio calling
- **Video Calls** - HD video calling with camera controls
- **Real-time Messaging** - Instant message delivery
- **Typing Indicators** - See when someone is typing
- **Call Controls** - Mute/unmute, video toggle, hang up
- **Call Timer** - Track call duration
- **Responsive Design** - Works on desktop and mobile
- **Gojo Theme** - Beautiful animated UI

## 🚀 Quick Start

### Option 1: Simple Demo
1. Open `index.html` in your browser
2. Allow camera and microphone permissions
3. Click the voice or video call buttons
4. Start chatting and calling!

### Option 2: With Signaling Server
1. Install dependencies: `npm install`
2. Start server: `npm start`
3. Open `http://localhost:3001`

## 📱 How to Use

### Chat Interface
- **Send Messages**: Type in the input field and press Enter or click send
- **Typing Indicator**: Shows when the other person is typing
- **Message History**: Scroll up to see previous messages

### Voice Calls
1. Click the green phone button in the chat header
2. Allow microphone access when prompted
3. Use call controls to mute/unmute
4. Click the red hang up button to end the call

### Video Calls
1. Click the blue video button in the chat header
2. Allow camera and microphone access when prompted
3. Use call controls to toggle video/audio
4. Click the red hang up button to end the call

### Call Controls
- **Microphone Button**: Mute/unmute your audio
- **Video Button**: Turn camera on/off
- **Hang Up Button**: End the call

## 🎨 Design Features

- **Gojo Satoru Theme**: Blue and purple gradient colors
- **Smooth Animations**: Hover effects and transitions
- **Pulse Effects**: Caller avatar pulses during incoming calls
- **Responsive Layout**: Adapts to different screen sizes
- **Modern UI**: Clean, minimalist design

## 🔧 Technical Details

- **Frontend**: HTML5, CSS3, JavaScript (ES6+)
- **WebRTC**: Peer-to-peer video/audio communication
- **STUN Servers**: Google's public STUN servers
- **Responsive**: Mobile-first design approach

## 📁 File Structure

```
call/
├── index.html          # Main chat interface
├── webrtc.js          # WebRTC implementation
├── package.json       # Dependencies
├── signaling-server.js # Optional signaling server
└── README.md          # This file
```

## 🎯 Key Components

### Chat Interface
- Message bubbles (sent/received)
- Typing indicators
- Message input with send button
- Contact information display

### Call System
- Voice call button (green phone icon)
- Video call button (blue video icon)
- Call popup with controls
- Call timer and status

### Call Controls
- Mute/unmute microphone
- Toggle video on/off
- Hang up call
- Call duration timer

## 🔒 Privacy & Security

- **Local Processing**: Messages and calls processed locally
- **No Data Storage**: No messages or calls are stored
- **HTTPS Required**: Camera/microphone access requires secure context
- **Permission Based**: User must grant camera/microphone access

## 📱 Browser Compatibility

- Chrome 56+
- Firefox 52+
- Safari 11+
- Edge 79+

## 🎨 Customization

### Colors
The theme uses CSS custom properties. Modify these in `index.html`:

```css
:root {
    --primary-color: #00bfff;
    --secondary-color: #9d00ff;
    --accent-color: #87cefa;
    --background: #0a0a0a;
}
```

### Layout
- **Sidebar Width**: Change `.sidebar` width
- **Message Bubbles**: Modify `.message-content` styles
- **Call Popup**: Adjust `.call-popup` dimensions

## 🚨 Troubleshooting

### Common Issues

1. **Camera/Microphone Access Denied**
   - Ensure you're using HTTPS
   - Check browser permissions
   - Try refreshing the page

2. **Call Not Working**
   - Check if WebRTC is supported
   - Verify camera/microphone permissions
   - Try different browser

3. **Messages Not Sending**
   - Check if input field is focused
   - Try pressing Enter or clicking send button

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## 📄 License

MIT License - see LICENSE file for details

## 🙏 Acknowledgments

- **Gojo Satoru Theme**: Inspired by Jujutsu Kaisen
- **WhatsApp Design**: Inspired by WhatsApp's clean interface
- **WebRTC**: Google's WebRTC technology

---

**"Throughout heaven and earth, I alone am the honored one."** - Gojo Satoru

*Built with ❤️ by Eugene @ Synergy College*
