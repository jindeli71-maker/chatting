#!/usr/bin/env node

const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');

console.log('🌀 Gojo Call System Setup');
console.log('========================\n');

// Check if package.json exists
const packageJsonPath = path.join(__dirname, 'package.json');
if (!fs.existsSync(packageJsonPath)) {
    console.error('❌ package.json not found. Please run this script from the call directory.');
    process.exit(1);
}

// Check Node.js version
const nodeVersion = process.version;
const majorVersion = parseInt(nodeVersion.slice(1).split('.')[0]);

if (majorVersion < 14) {
    console.error(`❌ Node.js version ${nodeVersion} is not supported. Please upgrade to Node.js 14 or higher.`);
    process.exit(1);
}

console.log(`✅ Node.js version: ${nodeVersion}`);

// Install dependencies
console.log('\n📦 Installing dependencies...');
exec('npm install', (error, stdout, stderr) => {
    if (error) {
        console.error('❌ Failed to install dependencies:', error.message);
        process.exit(1);
    }
    
    console.log('✅ Dependencies installed successfully');
    
    // Create .env file if it doesn't exist
    const envPath = path.join(__dirname, '.env');
    if (!fs.existsSync(envPath)) {
        const envContent = `# Gojo Call System Configuration
PORT=3001
NODE_ENV=development

# STUN/TURN Server Configuration
STUN_SERVERS=stun.l.google.com:19302,stun1.l.google.com:19302

# Optional: Add your TURN server credentials
# TURN_USERNAME=your_username
# TURN_CREDENTIAL=your_password
`;
        
        fs.writeFileSync(envPath, envContent);
        console.log('✅ Created .env file with default configuration');
    }
    
    // Create logs directory
    const logsDir = path.join(__dirname, 'logs');
    if (!fs.existsSync(logsDir)) {
        fs.mkdirSync(logsDir);
        console.log('✅ Created logs directory');
    }
    
    console.log('\n🎉 Setup completed successfully!');
    console.log('\n📋 Next steps:');
    console.log('1. Start the signaling server: npm start');
    console.log('2. Open http://localhost:3001 in your browser');
    console.log('3. Allow camera and microphone permissions');
    console.log('4. Start making calls!');
    console.log('\n💡 For development mode: npm run dev');
    console.log('\n📚 Read README.md for more information');
    console.log('\n"Throughout heaven and earth, I alone am the honored one." - Gojo Satoru');
});
