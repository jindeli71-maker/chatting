const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = socketIo(server, {
    cors: {
        origin: "*",
        methods: ["GET", "POST"]
    }
});

const PORT = process.env.PORT || 3001;

// Serve static files
app.use(express.static(path.join(__dirname)));

// Store active rooms and connections
const rooms = new Map();
const connections = new Map();

// Socket.io connection handling
io.on('connection', (socket) => {
    console.log('User connected:', socket.id);
    
    // Store connection info
    connections.set(socket.id, {
        socketId: socket.id,
        roomId: null,
        username: null,
        connectedAt: new Date()
    });

    // Join room
    socket.on('join-room', (data) => {
        const { roomId, username } = data;
        
        if (!roomId || !username) {
            socket.emit('error', { message: 'Room ID and username are required' });
            return;
        }

        // Update connection info
        const connection = connections.get(socket.id);
        connection.roomId = roomId;
        connection.username = username;

        // Leave previous room if any
        if (connection.roomId) {
            socket.leave(connection.roomId);
        }

        // Join new room
        socket.join(roomId);
        
        // Initialize room if it doesn't exist
        if (!rooms.has(roomId)) {
            rooms.set(roomId, {
                id: roomId,
                participants: new Map(),
                createdAt: new Date()
            });
        }

        const room = rooms.get(roomId);
        room.participants.set(socket.id, {
            socketId: socket.id,
            username: username,
            joinedAt: new Date()
        });

        console.log(`User ${username} joined room ${roomId}`);
        
        // Notify others in the room
        socket.to(roomId).emit('user-joined', {
            socketId: socket.id,
            username: username
        });

        // Send list of existing participants to the new user
        const participants = Array.from(room.participants.values()).filter(p => p.socketId !== socket.id);
        socket.emit('room-joined', {
            roomId: roomId,
            participants: participants
        });

        // Send room info
        socket.emit('room-info', {
            roomId: roomId,
            participantCount: room.participants.size,
            participants: Array.from(room.participants.values())
        });
    });

    // Handle WebRTC signaling
    socket.on('webrtc-signal', (data) => {
        const connection = connections.get(socket.id);
        if (!connection || !connection.roomId) {
            socket.emit('error', { message: 'Not in a room' });
            return;
        }

        // Forward the signal to other participants in the room
        socket.to(connection.roomId).emit('webrtc-signal', {
            from: socket.id,
            signal: data
        });
    });

    // Handle chat messages
    socket.on('chat-message', (data) => {
        const connection = connections.get(socket.id);
        if (!connection || !connection.roomId) {
            return;
        }

        const message = {
            id: Date.now().toString(),
            from: socket.id,
            username: connection.username,
            message: data.message,
            timestamp: new Date()
        };

        // Broadcast to all participants in the room
        io.to(connection.roomId).emit('chat-message', message);
    });

    // Handle screen sharing
    socket.on('screen-share-start', (data) => {
        const connection = connections.get(socket.id);
        if (!connection || !connection.roomId) {
            return;
        }

        socket.to(connection.roomId).emit('screen-share-start', {
            from: socket.id,
            username: connection.username
        });
    });

    socket.on('screen-share-stop', () => {
        const connection = connections.get(socket.id);
        if (!connection || !connection.roomId) {
            return;
        }

        socket.to(connection.roomId).emit('screen-share-stop', {
            from: socket.id,
            username: connection.username
        });
    });

    // Handle file sharing
    socket.on('file-share', (data) => {
        const connection = connections.get(socket.id);
        if (!connection || !connection.roomId) {
            return;
        }

        const fileData = {
            from: socket.id,
            username: connection.username,
            fileName: data.fileName,
            fileSize: data.fileSize,
            fileType: data.fileType,
            data: data.data,
            timestamp: new Date()
        };

        socket.to(connection.roomId).emit('file-share', fileData);
    });

    // Handle disconnect
    socket.on('disconnect', () => {
        console.log('User disconnected:', socket.id);
        
        const connection = connections.get(socket.id);
        if (connection && connection.roomId) {
            const room = rooms.get(connection.roomId);
            if (room) {
                room.participants.delete(socket.id);
                
                // Notify others in the room
                socket.to(connection.roomId).emit('user-left', {
                    socketId: socket.id,
                    username: connection.username
                });

                // Clean up empty rooms
                if (room.participants.size === 0) {
                    rooms.delete(connection.roomId);
                    console.log(`Room ${connection.roomId} deleted (empty)`);
                }
            }
        }

        connections.delete(socket.id);
    });

    // Handle errors
    socket.on('error', (error) => {
        console.error('Socket error:', error);
    });
});

// API endpoints
app.get('/api/rooms', (req, res) => {
    const roomList = Array.from(rooms.values()).map(room => ({
        id: room.id,
        participantCount: room.participants.size,
        createdAt: room.createdAt,
        participants: Array.from(room.participants.values())
    }));
    
    res.json(roomList);
});

app.get('/api/rooms/:roomId', (req, res) => {
    const roomId = req.params.roomId;
    const room = rooms.get(roomId);
    
    if (!room) {
        return res.status(404).json({ error: 'Room not found' });
    }
    
    res.json({
        id: room.id,
        participantCount: room.participants.size,
        createdAt: room.createdAt,
        participants: Array.from(room.participants.values())
    });
});

app.get('/api/stats', (req, res) => {
    res.json({
        totalRooms: rooms.size,
        totalConnections: connections.size,
        uptime: process.uptime(),
        memoryUsage: process.memoryUsage()
    });
});

// Health check
app.get('/health', (req, res) => {
    res.json({ status: 'OK', timestamp: new Date() });
});

// Start server
server.listen(PORT, () => {
    console.log(`🚀 Signaling server running on port ${PORT}`);
    console.log(`📡 WebSocket endpoint: ws://localhost:${PORT}`);
    console.log(`🌐 Web interface: http://localhost:${PORT}`);
});

// Graceful shutdown
process.on('SIGTERM', () => {
    console.log('SIGTERM received, shutting down gracefully');
    server.close(() => {
        console.log('Process terminated');
        process.exit(0);
    });
});

process.on('SIGINT', () => {
    console.log('SIGINT received, shutting down gracefully');
    server.close(() => {
        console.log('Process terminated');
        process.exit(0);
    });
});

module.exports = { app, server, io };
