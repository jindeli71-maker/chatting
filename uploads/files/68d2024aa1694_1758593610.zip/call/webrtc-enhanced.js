class WebRTCManagerEnhanced {
    constructor() {
        this.localStream = null;
        this.remoteStream = null;
        this.peerConnection = null;
        this.dataChannel = null;
        this.socket = null;
        this.currentRoomId = null;
        this.currentUsername = null;
        this.isVideoEnabled = true;
        this.isAudioEnabled = true;
        this.callStartTime = null;
        this.remotePeerId = null;
        
        // Configuration for STUN/TURN servers
        this.configuration = {
            iceServers: [
                { urls: 'stun:stun.l.google.com:19302' },
                { urls: 'stun:stun1.l.google.com:19302' },
                { urls: 'stun:stun2.l.google.com:19302' },
                { urls: 'stun:stun3.l.google.com:19302' },
                { urls: 'stun:stun4.l.google.com:19302' }
            ]
        };

        // Event callbacks
        this.onCallStateChange = null;
        this.onCallEnd = null;
        this.onNotification = null;
        this.onRemoteStream = null;
        this.onChatMessage = null;
        this.onUserJoined = null;
        this.onUserLeft = null;

        this.initializeElements();
        this.initializeSocket();
    }

    initializeElements() {
        this.localVideo = document.getElementById('localVideo');
        this.remoteVideo = document.getElementById('remoteVideo');
        this.localVideoWrapper = document.getElementById('localVideoWrapper');
        this.remoteVideoWrapper = document.getElementById('remoteVideoWrapper');
        this.videoGrid = document.getElementById('videoGrid');
    }

    initializeSocket() {
        // Connect to signaling server
        this.socket = io('http://localhost:3001');
        
        this.socket.on('connect', () => {
            console.log('Connected to signaling server');
            this.notify('Connected to server', 'success');
        });

        this.socket.on('disconnect', () => {
            console.log('Disconnected from signaling server');
            this.notify('Disconnected from server', 'warning');
        });

        this.socket.on('error', (error) => {
            console.error('Socket error:', error);
            this.notify('Connection error: ' + error.message, 'error');
        });

        this.socket.on('user-joined', (data) => {
            console.log('User joined:', data);
            this.notify(`${data.username} joined the call`, 'info');
            if (this.onUserJoined) {
                this.onUserJoined(data);
            }
        });

        this.socket.on('user-left', (data) => {
            console.log('User left:', data);
            this.notify(`${data.username} left the call`, 'info');
            if (this.onUserLeft) {
                this.onUserLeft(data);
            }
        });

        this.socket.on('webrtc-signal', (data) => {
            this.handleSignalingMessage(data.signal, data.from);
        });

        this.socket.on('chat-message', (message) => {
            if (this.onChatMessage) {
                this.onChatMessage(message);
            }
        });

        this.socket.on('room-joined', (data) => {
            console.log('Room joined:', data);
            this.notify(`Joined room ${data.roomId}`, 'success');
        });

        this.socket.on('room-info', (data) => {
            console.log('Room info:', data);
        });
    }

    async startCall(roomId, username) {
        try {
            this.currentRoomId = roomId;
            this.currentUsername = username;
            this.callStartTime = new Date();

            // Get user media
            await this.getUserMedia();

            // Join room via socket
            this.socket.emit('join-room', { roomId, username });

            this.updateCallState('connecting');
            this.notify('Starting call...', 'info');

        } catch (error) {
            console.error('Error starting call:', error);
            this.notify('Failed to start call: ' + error.message, 'error');
        }
    }

    async getUserMedia() {
        try {
            const constraints = {
                video: {
                    width: { ideal: 1280 },
                    height: { ideal: 720 },
                    frameRate: { ideal: 30 }
                },
                audio: {
                    echoCancellation: true,
                    noiseSuppression: true,
                    autoGainControl: true
                }
            };

            this.localStream = await navigator.mediaDevices.getUserMedia(constraints);
            this.localVideo.srcObject = this.localStream;

            this.notify('Camera and microphone access granted', 'success');

        } catch (error) {
            console.error('Error accessing media devices:', error);
            this.notify('Camera/microphone access denied: ' + error.message, 'error');
            throw error;
        }
    }

    async createPeerConnection(remotePeerId) {
        this.remotePeerId = remotePeerId;
        this.peerConnection = new RTCPeerConnection(this.configuration);

        // Handle incoming remote stream
        this.peerConnection.ontrack = (event) => {
            console.log('Received remote stream');
            this.remoteStream = event.streams[0];
            this.remoteVideo.srcObject = this.remoteStream;
            this.remoteVideoWrapper.style.display = 'block';
            this.updateVideoLayout();
            
            if (this.onRemoteStream) {
                this.onRemoteStream(this.remoteStream);
            }
        };

        // Handle ICE candidates
        this.peerConnection.onicecandidate = (event) => {
            if (event.candidate) {
                console.log('Sending ICE candidate');
                this.sendSignalingMessage({
                    type: 'ice-candidate',
                    candidate: event.candidate
                });
            }
        };

        // Handle connection state changes
        this.peerConnection.onconnectionstatechange = () => {
            console.log('Connection state:', this.peerConnection.connectionState);
            
            switch (this.peerConnection.connectionState) {
                case 'connected':
                    this.updateCallState('connected');
                    this.notify('Call connected!', 'success');
                    break;
                case 'disconnected':
                case 'failed':
                case 'closed':
                    this.updateCallState('disconnected');
                    this.notify('Call disconnected', 'warning');
                    this.cleanup();
                    break;
            }
        };

        // Add local stream tracks
        if (this.localStream) {
            this.localStream.getTracks().forEach(track => {
                this.peerConnection.addTrack(track, this.localStream);
            });
        }

        // Create data channel
        this.createDataChannel();
    }

    createDataChannel() {
        this.dataChannel = this.peerConnection.createDataChannel('chat', {
            ordered: true
        });

        this.dataChannel.onopen = () => {
            console.log('Data channel opened');
        };

        this.dataChannel.onmessage = (event) => {
            const message = JSON.parse(event.data);
            this.handleDataChannelMessage(message);
        };

        this.peerConnection.ondatachannel = (event) => {
            const channel = event.channel;
            channel.onmessage = (event) => {
                const message = JSON.parse(event.data);
                this.handleDataChannelMessage(message);
            };
        };
    }

    handleDataChannelMessage(message) {
        switch (message.type) {
            case 'chat':
                if (this.onChatMessage) {
                    this.onChatMessage(message.data);
                }
                break;
            case 'file':
                this.handleFileMessage(message.data);
                break;
        }
    }

    handleFileMessage(fileData) {
        // Handle file sharing
        console.log('Received file:', fileData);
        this.notify(`Received file: ${fileData.fileName}`, 'info');
    }

    async handleSignalingMessage(message, from) {
        // Only handle messages from the remote peer
        if (from === this.remotePeerId) {
            switch (message.type) {
                case 'offer':
                    await this.handleOffer(message.offer);
                    break;
                case 'answer':
                    await this.handleAnswer(message.answer);
                    break;
                case 'ice-candidate':
                    await this.handleIceCandidate(message.candidate);
                    break;
            }
        }
    }

    async handleOffer(offer) {
        try {
            if (!this.peerConnection) {
                await this.createPeerConnection(this.remotePeerId);
            }
            
            await this.peerConnection.setRemoteDescription(offer);
            const answer = await this.peerConnection.createAnswer();
            await this.peerConnection.setLocalDescription(answer);
            
            this.sendSignalingMessage({
                type: 'answer',
                answer: answer
            });
        } catch (error) {
            console.error('Error handling offer:', error);
        }
    }

    async handleAnswer(answer) {
        try {
            await this.peerConnection.setRemoteDescription(answer);
        } catch (error) {
            console.error('Error handling answer:', error);
        }
    }

    async handleIceCandidate(candidate) {
        try {
            await this.peerConnection.addIceCandidate(candidate);
        } catch (error) {
            console.error('Error handling ICE candidate:', error);
        }
    }

    sendSignalingMessage(message) {
        if (this.socket) {
            this.socket.emit('webrtc-signal', message);
        }
    }

    sendChatMessage(message) {
        if (this.socket) {
            this.socket.emit('chat-message', { message });
        }
    }

    sendFile(file) {
        const reader = new FileReader();
        reader.onload = (e) => {
            const fileData = {
                fileName: file.name,
                fileSize: file.size,
                fileType: file.type,
                data: e.target.result
            };
            
            if (this.dataChannel && this.dataChannel.readyState === 'open') {
                this.dataChannel.send(JSON.stringify({
                    type: 'file',
                    data: fileData
                }));
            } else if (this.socket) {
                this.socket.emit('file-share', fileData);
            }
        };
        reader.readAsDataURL(file);
    }

    toggleVideo() {
        if (this.localStream) {
            const videoTrack = this.localStream.getVideoTracks()[0];
            if (videoTrack) {
                videoTrack.enabled = !videoTrack.enabled;
                this.isVideoEnabled = videoTrack.enabled;
                
                const btn = document.getElementById('toggleVideo');
                const icon = btn.querySelector('i');
                
                if (this.isVideoEnabled) {
                    icon.className = 'fas fa-video';
                    btn.innerHTML = '<i class="fas fa-video"></i> Video On';
                } else {
                    icon.className = 'fas fa-video-slash';
                    btn.innerHTML = '<i class="fas fa-video-slash"></i> Video Off';
                }
                
                this.notify(`Video ${this.isVideoEnabled ? 'enabled' : 'disabled'}`, 'info');
            }
        }
    }

    toggleAudio() {
        if (this.localStream) {
            const audioTrack = this.localStream.getAudioTracks()[0];
            if (audioTrack) {
                audioTrack.enabled = !audioTrack.enabled;
                this.isAudioEnabled = audioTrack.enabled;
                
                const btn = document.getElementById('toggleAudio');
                const icon = btn.querySelector('i');
                
                if (this.isAudioEnabled) {
                    icon.className = 'fas fa-microphone';
                    btn.innerHTML = '<i class="fas fa-microphone"></i> Audio On';
                } else {
                    icon.className = 'fas fa-microphone-slash';
                    btn.innerHTML = '<i class="fas fa-microphone-slash"></i> Audio Off';
                }
                
                this.notify(`Audio ${this.isAudioEnabled ? 'enabled' : 'disabled'}`, 'info');
            }
        }
    }

    updateVideoLayout() {
        const localWrapper = this.localVideoWrapper;
        const remoteWrapper = this.remoteVideoWrapper;
        
        if (this.remoteStream || this.remoteVideo.srcObject) {
            // Both videos visible
            this.videoGrid.style.gridTemplateColumns = '1fr 1fr';
            localWrapper.classList.remove('single');
            remoteWrapper.classList.remove('single');
        } else {
            // Only local video visible
            this.videoGrid.style.gridTemplateColumns = '1fr';
            localWrapper.classList.add('single');
        }
    }

    updateCallState(state) {
        if (this.onCallStateChange) {
            this.onCallStateChange(state);
        }
    }

    notify(message, type) {
        if (this.onNotification) {
            this.onNotification(message, type);
        }
    }

    endCall() {
        this.cleanup();
        this.updateCallState('disconnected');
        
        if (this.callStartTime) {
            const duration = this.formatDuration(new Date() - this.callStartTime);
            if (this.onCallEnd) {
                this.onCallEnd(duration, 'Ended by user');
            }
        }
        
        this.notify('Call ended', 'info');
    }

    cleanup() {
        // Stop local stream
        if (this.localStream) {
            this.localStream.getTracks().forEach(track => {
                track.stop();
            });
            this.localStream = null;
        }

        // Close peer connection
        if (this.peerConnection) {
            this.peerConnection.close();
            this.peerConnection = null;
        }

        // Clear video elements
        this.localVideo.srcObject = null;
        this.remoteVideo.srcObject = null;
        this.remoteVideoWrapper.style.display = 'none';
        this.updateVideoLayout();

        // Reset state
        this.currentRoomId = null;
        this.currentUsername = null;
        this.callStartTime = null;
        this.remotePeerId = null;
    }

    formatDuration(milliseconds) {
        const seconds = Math.floor(milliseconds / 1000);
        const minutes = Math.floor(seconds / 60);
        const hours = Math.floor(minutes / 60);

        if (hours > 0) {
            return `${hours}:${(minutes % 60).toString().padStart(2, '0')}:${(seconds % 60).toString().padStart(2, '0')}`;
        } else {
            return `${minutes}:${(seconds % 60).toString().padStart(2, '0')}`;
        }
    }

    // Utility methods
    getCallDuration() {
        if (this.callStartTime) {
            return this.formatDuration(new Date() - this.callStartTime);
        }
        return '0:00';
    }

    isInCall() {
        return this.peerConnection && this.peerConnection.connectionState === 'connected';
    }

    getConnectionStats() {
        if (this.peerConnection) {
            return this.peerConnection.getStats();
        }
        return null;
    }
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = WebRTCManagerEnhanced;
}
