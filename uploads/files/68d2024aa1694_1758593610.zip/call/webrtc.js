class WebRTCManager {
    constructor() {
        this.localStream = null;
        this.remoteStream = null;
        this.peerConnection = null;
        this.currentRoomId = null;
        this.currentUsername = null;
        this.isVideoEnabled = true;
        this.isAudioEnabled = true;
        this.callStartTime = null;
        
        // Configuration for STUN servers
        this.configuration = {
            iceServers: [
                { urls: 'stun:stun.l.google.com:19302' },
                { urls: 'stun:stun1.l.google.com:19302' },
                { urls: 'stun:stun2.l.google.com:19302' },
                { urls: 'stun:stun3.l.google.com:19302' },
                { urls: 'stun:stun4.l.google.com:19302' }
            ]
        };

        // Event callbacks
        this.onCallStateChange = null;
        this.onCallEnd = null;
        this.onNotification = null;
        this.onRemoteStream = null;
    }

    async startCall(roomId, username) {
        try {
            this.currentRoomId = roomId;
            this.currentUsername = username;
            this.callStartTime = new Date();

            // Get user media
            await this.getUserMedia();

            // Create peer connection
            this.createPeerConnection();

            // Simulate connection for demo
            this.simulateConnection();

            this.updateCallState('connecting');
            this.notify('Starting call...', 'info');

        } catch (error) {
            console.error('Error starting call:', error);
            this.notify('Failed to start call: ' + error.message, 'error');
        }
    }

    async getUserMedia() {
        try {
            const constraints = {
                video: {
                    width: { ideal: 640 },
                    height: { ideal: 480 },
                    frameRate: { ideal: 30 }
                },
                audio: {
                    echoCancellation: true,
                    noiseSuppression: true,
                    autoGainControl: true
                }
            };

            this.localStream = await navigator.mediaDevices.getUserMedia(constraints);
            this.notify('Camera and microphone access granted', 'success');

        } catch (error) {
            console.error('Error accessing media devices:', error);
            this.notify('Camera/microphone access denied: ' + error.message, 'error');
            throw error;
        }
    }

    createPeerConnection() {
        this.peerConnection = new RTCPeerConnection(this.configuration);

        // Handle incoming remote stream
        this.peerConnection.ontrack = (event) => {
            console.log('Received remote stream');
            this.remoteStream = event.streams[0];
            
            if (this.onRemoteStream) {
                this.onRemoteStream(this.remoteStream);
            }
        };

        // Handle ICE candidates
        this.peerConnection.onicecandidate = (event) => {
            if (event.candidate) {
                console.log('Sending ICE candidate');
                // In a real implementation, send this to the remote peer via signaling server
            }
        };

        // Handle connection state changes
        this.peerConnection.onconnectionstatechange = () => {
            console.log('Connection state:', this.peerConnection.connectionState);
            
            switch (this.peerConnection.connectionState) {
                case 'connected':
                    this.updateCallState('connected');
                    this.notify('Call connected!', 'success');
                    break;
                case 'disconnected':
                case 'failed':
                case 'closed':
                    this.updateCallState('disconnected');
                    this.notify('Call disconnected', 'warning');
                    this.cleanup();
                    break;
            }
        };

        // Add local stream tracks
        if (this.localStream) {
            this.localStream.getTracks().forEach(track => {
                this.peerConnection.addTrack(track, this.localStream);
            });
        }
    }

    simulateConnection() {
        // For demo purposes, simulate a connection after 2 seconds
        setTimeout(() => {
            this.updateCallState('connected');
            this.notify('Demo call connected!', 'success');
        }, 2000);
    }

    toggleVideo() {
        if (this.localStream) {
            const videoTrack = this.localStream.getVideoTracks()[0];
            if (videoTrack) {
                videoTrack.enabled = !videoTrack.enabled;
                this.isVideoEnabled = videoTrack.enabled;
                this.notify(`Video ${this.isVideoEnabled ? 'enabled' : 'disabled'}`, 'info');
            }
        }
    }

    toggleAudio() {
        if (this.localStream) {
            const audioTrack = this.localStream.getAudioTracks()[0];
            if (audioTrack) {
                audioTrack.enabled = !audioTrack.enabled;
                this.isAudioEnabled = audioTrack.enabled;
                this.notify(`Audio ${this.isAudioEnabled ? 'enabled' : 'disabled'}`, 'info');
            }
        }
    }

    updateCallState(state) {
        if (this.onCallStateChange) {
            this.onCallStateChange(state);
        }
    }

    notify(message, type) {
        if (this.onNotification) {
            this.onNotification(message, type);
        }
    }

    endCall() {
        this.cleanup();
        this.updateCallState('disconnected');
        
        if (this.callStartTime) {
            const duration = this.formatDuration(new Date() - this.callStartTime);
            if (this.onCallEnd) {
                this.onCallEnd(duration, 'Ended by user');
            }
        }
        
        this.notify('Call ended', 'info');
    }

    cleanup() {
        // Stop local stream
        if (this.localStream) {
            this.localStream.getTracks().forEach(track => {
                track.stop();
            });
            this.localStream = null;
        }

        // Close peer connection
        if (this.peerConnection) {
            this.peerConnection.close();
            this.peerConnection = null;
        }

        // Reset state
        this.currentRoomId = null;
        this.currentUsername = null;
        this.callStartTime = null;
    }

    formatDuration(milliseconds) {
        const seconds = Math.floor(milliseconds / 1000);
        const minutes = Math.floor(seconds / 60);
        const hours = Math.floor(minutes / 60);

        if (hours > 0) {
            return `${hours}:${(minutes % 60).toString().padStart(2, '0')}:${(seconds % 60).toString().padStart(2, '0')}`;
        } else {
            return `${minutes}:${(seconds % 60).toString().padStart(2, '0')}`;
        }
    }

    // Utility methods
    getCallDuration() {
        if (this.callStartTime) {
            return this.formatDuration(new Date() - this.callStartTime);
        }
        return '0:00';
    }

    isInCall() {
        return this.peerConnection && this.peerConnection.connectionState === 'connected';
    }
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = WebRTCManager;
}